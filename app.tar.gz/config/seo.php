<?php

return [

  /*
  |--------------------------------------------------------------------------
  | Seo title (General)
  |--------------------------------------------------------------------------
  |
  | Used for SEO (Pagetitle, Open Graph Title etc.)
  |
  */

  'title' => 'Oxid Architektur GmbH',

  /*
  |--------------------------------------------------------------------------
  | Seo description (General)
  |--------------------------------------------------------------------------
  |
  | Used for SEO (Meta description, Open Graph Description)
  |
  */

  'description' => 'Oxid Architektur GmbH - Zürich',   

];