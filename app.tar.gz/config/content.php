<?php

return [

  'content_keys' => [
    [
      'key' => 'home',
      'page' => 'Startseite'
    ],
    [
      'key' => 'haltung',
      'page' => 'Profil > Haltung'
    ],
    [
      'key' => 'kompetenzen',
      'page' => 'Profil > Kompetenzen'
    ],
    [
      'key' => 'kunden',
      'page' => 'Profil > Kunden'
    ],
    [
      'key' => 'impressum',
      'page' => 'Profil > Impressum'
    ],
  ]

];
