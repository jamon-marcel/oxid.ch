<?php

return [

  'program' => [
    1 => 'living',
    2 => 'industry',
    3 => 'hybrid',
    4 => 'public',
  ],

  'state' => [
    1 => 'built',
    2 => 'planned',
    3 => 'competition',
  ],

  'authors' => [
    1 => 'Oxid',
    2 => 'BuSu',
    3 => 'MB/CS'
  ],

  'discourseCategories' => [
    1 => 'research',
    2 => 'events',
    3 => 'publications'
  ],

  'teamCategories' => [
    1 => 'partner',
    2 => 'employee',
    3 => 'alumni'
  ],

];
