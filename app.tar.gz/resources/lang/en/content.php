<?php

return [

  /*
  |--------------------------------------------------------------------------
  | Content language file
  |--------------------------------------------------------------------------
  |
  */

  // Team
  'cv' => 'CV',

  // Authors (Works)
  'author_heading_1'      => 'Marianne Burkhalter und Christian Sumi, <span class="nobr">ab 1984</span>',
  'author_heading_2'      => 'Burkhalter Sumi Architekten, <span class="nobr">ab 2009</span>',
  'author_heading_3'      => 'Oxid Architektur, <span class="nobr">ab 2020</span>',
  'author_description_1'  => 'Marianne Burkhalter, Partnerin<br>Christian Sumi, Partner',
  'author_description_2'  => 'Marianne Burkhalter, Partnerin / Christian Sumi, Partner<br>Yves Schihin, Partner / Urs Rinklef, Partner (2012)',
  'author_description_3'  => 'Yves Schihin, Partner<br>Urs Rinklef, Partner',
];
