<?php

return [

  /*
  |--------------------------------------------------------------------------
  | Content language file
  |--------------------------------------------------------------------------
  |
  */

  // Team
  'cv' => 'Lebenslauf',

  // Authors (Works)
  'author_heading_1'      => 'Oxid Architektur',
  'author_heading_2'      => 'Burkhalter Sumi Architekten',
  'author_heading_3'      => 'Marianne Burkhalter und Christian Sumi',
  'author_description_1'  => 'Yves Schihin, Partner<br>Urs Rinklef, Partner',
  'author_description_2'  => 'Marianne Burkhalter, Partnerin / Christian Sumi, Partner<br>Yves Schihin, Partner / Urs Rinklef, Partner (2012)',
  'author_description_3'  => 'Marianne Burkhalter, Partnerin<br>Christian Sumi, Partner',

];
