export default {
  title: {
    de: false
  },
}