export default {
  title: {
    de: null,
    en: null,
  },
  description: {
    de: null,
    en: null,
  },
  publish: 0,
};