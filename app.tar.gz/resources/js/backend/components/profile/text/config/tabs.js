export default {
  data: {
    key: 'data',
    label: 'Daten',
    active: true,
    error: false
  },
  translation: {
    key: 'translation',
    label: 'Übersetzung',
    active: false,
    error: false
  },
}