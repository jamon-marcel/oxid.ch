export default {
  heading: {
    de: false
  },
  date: {
    de: false
  },
  title: {
    de: false,
  },
  description_short: {
    de: false,
  },
}