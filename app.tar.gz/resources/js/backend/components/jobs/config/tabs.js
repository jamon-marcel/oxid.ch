export default {
  data: {
    key: 'data',
    label: 'Job',
    active: true,
    error: false
  },
  translation: {
    key: 'translation',
    label: 'Übersetzung',
    active: false,
    error: false
  },
  files: {
    key: 'files',
    label: 'Dokumente',
    active: false,
    error: false
  }
}