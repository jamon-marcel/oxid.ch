export default {
  title: {
    de: false,
  },
  description: {
    de: false,
  },
  info: {
    de: false,
  },
}