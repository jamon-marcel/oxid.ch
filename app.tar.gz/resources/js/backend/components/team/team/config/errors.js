export default {
  firstname: false,
  name: false,
}