<header class="site-header">
  @include('frontend.partials.icons.logo')
</header>