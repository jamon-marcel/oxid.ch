<script src="{{ asset('assets/js/app.js') }}" type="text/javascript"></script>
@if (request()->routeIs('page.contact'))
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCxU6MLGw6kEAd9ejc8GfqXx38qvm0oHPI"></script>
<script src="{{ asset('assets/js/maps.js') }}" type="text/javascript"></script>
@endif
</body>
<!-- made with ❤ by marceli.to & bivgrafik GmbH -->
</html>