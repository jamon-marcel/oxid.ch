<div class="menu-icon">
  <a href="javascript:;" class="icon-menu js-menu-btn">
    <svg class="icon-menu__open" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 18"><defs><style>.cls-1{fill:#181716;}</style></defs><rect class="cls-1" width="31.6" height="2"/><rect class="cls-1" y="8.2" width="31.6" height="2"/><rect class="cls-1" y="16.1" width="31.6" height="2"/></svg>
  </a>
</div>