<a href="/" class="logo" title="Home - Oxid Architektur">
  <img src="/assets/img/logo-oxid-arch.svg" width="231" height="89" alt="Logo Oxid Architektur">
</a>