<div class="menu-icon">
  <a href="javascript:;" class="icon-menu js-menu-btn">
    <svg class="icon-menu__close" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 44.5 44.5"><defs><style>.cls-1{fill:#181716;}</style></defs><polygon class="cls-1" points="44.5 1.8 43.1 0.4 22.4 21 1.4 0 0 1.4 21 22.4 0.4 43.1 1.8 44.5 22.4 23.9 42.8 44.2 44.2 42.8 23.9 22.4 44.5 1.8"/></svg>    
  </a>
</div>