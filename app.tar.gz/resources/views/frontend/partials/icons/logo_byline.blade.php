<div class="logo-byline">
  <img src="/assets/img/byline-oxid-arch.svg" width="300" height="45" alt="Byline Oxid Architektur">
</div>