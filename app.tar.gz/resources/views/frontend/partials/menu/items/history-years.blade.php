<ul class="{{request()->routeIs('page.history') ? 'is-visible' : ''}}">
  <li>
    <a href="">1984</a>
  </li>
  <li>
    <a href="">2009</a>
  </li>
  <li>
    <a href="">2020</a>
  </li>
</ul>