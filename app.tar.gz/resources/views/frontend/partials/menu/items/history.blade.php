<div class="menu-history">
  <h2>Bürogeschichte</h2>
  <ul class="{{request()->routeIs('page.history') ? 'is-visible' : ''}}">
    <li>
      <label>1984</label>
      <a href="javascript:;">Marianne Burkhalter und<br>Christian Sumi</a>
    </li>
    <li>
      <label>2009</label>
      <a href="javascript:;">Burkhalter Sumi Architekten</a>
    </li>
    <li>
      <label>2020</label>
      <a href="javascript:;">Oxid Architektur</a>
    </li>
  </ul>
</div>