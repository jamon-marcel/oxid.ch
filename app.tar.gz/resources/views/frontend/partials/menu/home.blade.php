<nav class="menu-home js-menu">
  @include('frontend.partials.menu.items.main')
</nav>