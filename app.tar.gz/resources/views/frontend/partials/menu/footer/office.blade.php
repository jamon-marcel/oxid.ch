<div class="menu-footer menu-footer--office">
  <h2 class="menu-footer__heading">Büro</h2>
  <nav class="menu-footer__nav">
    @include('frontend.partials.menu.items.office')
  </nav>
  <div class="menu-footer__info">
    <a href="javascript:;" class="anchor-ul is-active js-btn-info">Info</a>
  </div>
</div>