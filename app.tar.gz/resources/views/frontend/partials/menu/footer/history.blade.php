<div class="menu-footer menu-footer--history">
  <h2 class="menu-footer__heading">Geschichte</h2>
  <nav class="menu-footer__nav">
    @include('frontend.partials.menu.items.history-years')
  </nav>
  <div></div>
</div>