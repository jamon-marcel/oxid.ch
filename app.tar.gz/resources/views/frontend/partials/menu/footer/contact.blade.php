<div class="menu-footer menu-footer--contact">
  <h2 class="menu-footer__heading">Kontakt</h2>
</div>