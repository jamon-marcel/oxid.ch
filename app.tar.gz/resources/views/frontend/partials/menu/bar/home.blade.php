<div class="menu-bar is-home">
  <div class="menu-bar__open js-menu-bar">
    @include('frontend.partials.icons.menu_open')
    @include('frontend.partials.icons.logo_byline')
  </div>
  <div class="menu-bar__close is-hidden js-menu-bar">
    @include('frontend.partials.icons.menu_close')
    @include('frontend.partials.icons.logo_byline')
  </div>
</div>